# Flutter Instagram UI with Rest API

Layouting the UI for Instagram and creating the Rest API

## Youtube Link

[![Watch the video](https://img.youtube.com/vi/Gz_VvDrTnfw/sddefault.jpg)](https://youtu.be/Gz_VvDrTnfw)

https://youtu.be/Gz_VvDrTnfw

## API

- GET with pixabay.com


## ScreenShot

| Home         | Home           |
|--------------|----------------|
| <img src="img1.png" width="300"/> | <img src="img2.png" width="300"/>      |



